<h1>Welcome!</h1>

@if ($gosession === 'logged_in')
<p>You are logged in.</p>
@else
<p>You are not logged in.</p>
@endif
