<!-- resources/views/session-data.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Session Data</title>
</head>
<body>
    <h1>Session Data</h1>
    <ul>
        @foreach($data as $key => $value)
            <li><strong>{{ $key }}:</strong> {{ $value }}</li>
        @endforeach
    </ul>
</body>
</html>
