<h1>Welcome, {{ session('name') }}</h1>
<h1>Welcome, {{ session('study') }}</h1>
