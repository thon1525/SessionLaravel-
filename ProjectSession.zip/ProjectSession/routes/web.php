<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SessionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\View;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/createsession',[SessionController::class,'makeSession']);

Route::get('/session', function () {
    // Create a session variable.
    session()->put('name', 'Bard');
    session()->put('study', 'beltei university');
    // Render the view.
    return View::make('newsession');
});

Route::get('/show',[SessionController::class,'show']);

//////////////////////////

 /* Route::get('/playsession', function (Request $request) {
    // Get the session variable.
    $value = $request->session()->get('key', function () {
        return 'default';
    });
  
    // Render the view.
    return View::make('showsession',['inputsession'=>$value]);
});
  */
// The view file should be located at resources/views/welcome.blade.php.
// routes/web.php


// the file is not 
Route::get('/user', [SessionController::class, 'showdata']);

// the file for crate view 
Route::post('/add-team',[SessionController::class,'addTeam']);


