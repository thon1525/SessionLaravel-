<h1>Welcome, <?php echo e(session('name')); ?></h1>
<h1>Welcome, <?php echo e(session('study')); ?></h1>
<?php /**PATH D:\laravel\Session\ProjectSession\resources\views/newsession.blade.php ENDPATH**/ ?>