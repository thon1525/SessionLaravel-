<!-- resources/views/session-data.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Session Data</title>
</head>
<body>
    <h1>Session Data</h1>
    <ul>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><strong><?php echo e($key); ?>:</strong> <?php echo e($value); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH D:\laravel\Session\ProjectSession\resources\views/sessions.blade.php ENDPATH**/ ?>