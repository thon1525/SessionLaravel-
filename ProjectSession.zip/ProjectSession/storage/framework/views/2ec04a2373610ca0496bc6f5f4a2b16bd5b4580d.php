<h1>Welcome!</h1>

<?php if($gosession === 'logged_in'): ?>
<p>You are logged in.</p>
<?php else: ?>
<p>You are not logged in.</p>
<?php endif; ?>
<?php /**PATH D:\laravel\Session\ProjectSession\resources\views/show.blade.php ENDPATH**/ ?>