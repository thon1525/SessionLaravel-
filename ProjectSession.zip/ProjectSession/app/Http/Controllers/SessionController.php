<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;

use Illuminate\Http\Request;

class SessionController extends Controller
{
    public function makeSession(){

    }

    public function show(Request $request)
{
    // Get the session variable.
    $value = $request->session()->get('key', 'logged_in');

    // Check if the user is logged in.
    if ($value === 'logged_in') {
        return view('show',['gosession'=>$value]);
    } else {
        return ' No hello';
    }
}
 
  

}
