<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Request;
use Symfony\Component\Process\Process;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/formpersional', function () {
    return view('form');
});

Route::get('/form', function () {
    return view('formdatalaravel');
});

Route::get('/data', function () {
    return view("welcome");
});


Route::get('/formdataurl', function () {
    return view('formdata');
});

Route::get('/users',[UserController::class,'show']);

Route::post("/add-team",[UserController::class,'addTeam']);

/// the school
Route::get('/teams', function (Request $request) {
    $teams = $request->session()->get('user.teams');

    return view('user', ['teams' => $teams]);
});

///

Route::get('/showdata', function () {
    $value = session('key', 'default');
    
    return view('show', ['value' => $value]);
});

// this exmple for 

Route::post('/submit-form',[UserController::class,"show"])->name('submit-form');

// the route for detail for laravel 

Route::get('/showplay', function (Request $request) {
    $value = $request->session()->pull('key', 'default');

    return view('show', ['value' => $value]);
});

/// for the route for detail forl laravel for use controller


Route::post('/submit-form',[UserController::class,"showdataform"])->name('submit');

// the route for detail forl create session for example then 


// for the create post in route 
Route::post('/submit-form',[UserController::class,"showsessiondata"])->name('submitdata');

// for the create post in route 
Route::post('/submit-form',[UserController::class,"showsessioncrement"])->name('submitincrement');

// create session in laravel for this controller
Route::get('/big', [UserController::class,'usercontroller'])->name('create');

// create session in laravel for this controller
Route::post('/create', [UserController::class,'store'])->name('submitcreate');
