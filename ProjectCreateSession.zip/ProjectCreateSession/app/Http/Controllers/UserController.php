<?php
 
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;
 
class UserController extends Controller
{
    /**
     * Show the profile for the given user.
     */
   public function show(Request $request){
    
    $firstName = $request->input('fname');
    $lastName = $request->input('lname');
    $valuedata = session('key', $lastName);
    $valuedatatwo=session('key', $firstName);
    $data=['playsesion'=>$valuedata,
          'playsessiontwo'=>$valuedatatwo
   ];
   return view('showsession',$data);
    // Process the form data as needed
      
   }
public function showdataform(Request $request){
   $firstName = $request->input('fname');
   $lastName = $request->input('lname');
  $value = $request->session()->pull('key', $firstName);
  $valuedatathree = $request->session()->pull('key', $lastName);
 
  echo $value;
  echo "<br>";
  echo $valuedatathree;
}

public function showsessiondata(Request $request){
  $value = $request->session()->pull('key', 'default');

  return view('showdetail', ['value' => $value]);
}

public function usercontroller(){
  return view("create");
}


}