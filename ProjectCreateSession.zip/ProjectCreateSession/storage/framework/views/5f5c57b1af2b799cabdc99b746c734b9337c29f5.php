<!DOCTYPE html>
<html>
<head>
    <title>Show</title>
</head>
<body>
    <h1>Show</h1>
    <p>Value: <?php echo e($value); ?></p>
</body>
</html>
<?php /**PATH D:\laravel\Session\ProjectCreateSession\resources\views/showdetail.blade.php ENDPATH**/ ?>