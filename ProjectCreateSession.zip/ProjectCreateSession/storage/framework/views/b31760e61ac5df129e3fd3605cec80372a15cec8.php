<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>hello thon in session</h1><br>
 <p>hello ::<?php echo e($playsesion); ?></p>  <br>
 <p>number two hello::<?php echo e($playsessiontwo); ?>

</p>
</body>
</html><?php /**PATH D:\laravel\Session\ProjectCreateSession\resources\views/showsession.blade.php ENDPATH**/ ?>