

<!-- resources/views/form.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>HTML Form</title>
</head>
<body>

<h2>HTML Forms</h2>

<form action="{{ route('submit-form') }}" method="POST">
    @csrf
    <label for="fname">First name:</label><br>
    <input type="text" id="fname" name="fname" value="John"><br>
    <label for="lname">Last name:</label><br>
    <input type="text" id="lname" name="lname" value="Doe"><br><br>
    <input type="submit" value="Submit">
</form> 

<p>If you click the "Submit" button, the form data will be sent to the specified route for further processing.</p>

</body>
</html>
