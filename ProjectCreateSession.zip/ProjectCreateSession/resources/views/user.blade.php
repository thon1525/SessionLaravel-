<!DOCTYPE html>
<html>
<head>
    <title>Teams</title>
</head>
<body>
    <h1>Teams</h1>
    <ul>
        @foreach ($teams as $team)
            <li>{{ $team }}</li>
        @endforeach
    </ul>
</body>
</html>

