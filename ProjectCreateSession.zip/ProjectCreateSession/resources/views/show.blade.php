<!DOCTYPE html>
<html>
<head>
    <title>Show</title>
</head>
<body>
    <h1>Show</h1>
    <p>Value: {{ $value }}</p>
</body>
</html>
